import React         from 'react'
import MainComponent from './DragDropComponent.jsx'

React.render(
    <MainComponent />,
    document.getElementById('main')
)
