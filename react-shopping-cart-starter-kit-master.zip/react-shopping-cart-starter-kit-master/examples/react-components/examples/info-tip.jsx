return <div>
    reticulating splines
    <InfoTip><p>
        <a href="http://sims.wikia.com/wiki/Reticulating_splines">meaningless phrase</a>
    </p></InfoTip>
</div>;
