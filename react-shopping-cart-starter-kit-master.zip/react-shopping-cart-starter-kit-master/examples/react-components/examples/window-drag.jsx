var Indicator = React.createClass({
    render: function() {
        return <WindowDrag>
            {/* modal? */}
            <div>WINDOW DRAG!</div>
        </WindowDrag>;
    }
});

return <Indicator />;
