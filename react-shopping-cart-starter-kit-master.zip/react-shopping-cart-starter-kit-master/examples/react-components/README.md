[![Build Status](https://travis-ci.org/Khan/react-components.svg?branch=master)](https://travis-ci.org/Khan/react-components)

# Khan Academy React Components

Some components we build for Khan Academy that the world might find useful.

See http://khan.github.io/react-components/ for a demo and descriptions of
the individual components.

## License

[MIT License](http://opensource.org/licenses/MIT)
