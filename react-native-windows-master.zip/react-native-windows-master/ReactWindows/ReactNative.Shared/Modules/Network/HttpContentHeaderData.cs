﻿namespace ReactNative.Modules.Network
{
    struct HttpContentHeaderData
    {
        public string ContentType;
        public string ContentEncoding;
    }
}
