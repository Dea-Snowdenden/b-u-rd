﻿namespace ReactNative.Chakra.Executor
{
    enum LogLevel
    {
        Trace = 0,
        Info = 1,
        Warn = 2,
        Error = 3,
    }
}
