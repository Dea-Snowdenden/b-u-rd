const STATUS = {
	INIT: 1,
	DONE_LOADING: 2,
	LOADING: 3,
	ERROR: 4
};

export default STATUS;