# ATM-Redux-React
ATM app using Redux and React


## Notes
### Actions
- deposit money
- withdraw money
- update balance
- check balance if enough
- pay bill

### Store
- balance
- list of transactions