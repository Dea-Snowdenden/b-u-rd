import React from 'react';

// This component displays an individual message.
// We should have logic to display it on the right if the user sent the
// message, or on the left if it was received from someone else.
class Message extends React.Component {
  render() {
    // Display the message text and sender's name
  }
}

Message.defaultProps = {
};

export default Message;
