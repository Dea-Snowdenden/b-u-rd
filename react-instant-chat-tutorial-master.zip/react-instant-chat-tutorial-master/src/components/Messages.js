import React from 'react';

import Message from './Message';

// This is the main display of the application. It shows a list of all the
// messages which have been sent and received during the current chat session.
class Messages extends React.Component {
  render() {
    // Here we should loop through each message and
    // pass it to the Message component
  }
}

Messages.defaultProps = {
};

export default Messages;
