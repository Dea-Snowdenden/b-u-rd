require('../styles/App.css');
require('../styles/Login.css');

import React from 'react';
import ChatApp from './ChatApp';

// This is the first screen seen by the user. We should display some way for
// them to enter their name and enter the chat room
class App extends React.Component {
  render() {
    // Display a simple login screen with a username field and a submit button
  }

}
App.defaultProps = {
};

export default App;
