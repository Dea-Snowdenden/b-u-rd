import React from 'react';

// This component is where the user can type their message and send it
// to the chat room. We shouldn't communicate with the server here though.
class ChatInput extends React.Component {
  render() {
    // Display a user input form and do something when it is submitted
  }
}

ChatInput.defaultProps = {
};

export default ChatInput;
